CREATE TABLE auteur(
   id INT IDENTITY,
   nom VARCHAR(255),
   prenom VARCHAR(255),
   pseudo VARCHAR(255),
   is_deleted BIT DEFAULT 0,
   PRIMARY KEY(id),
   UNIQUE(pseudo)
);

CREATE TABLE article(
   id INT IDENTITY,
   titre VARCHAR(255),
   texte VARCHAR(max),
   published_date DATETIME2,
   is_deleted BIT DEFAULT 0,
   Id_auteur INT,
   PRIMARY KEY(id),
   FOREIGN KEY(Id_auteur) REFERENCES auteur(id)
);

CREATE TABLE tag(
   id INT IDENTITY,
   mot VARCHAR(255),
   is_deleted BIT DEFAULT 0,
   PRIMARY KEY(id),
   UNIQUE(mot)
);

CREATE TABLE app_user(
   id INT IDENTITY,
   login VARCHAR(255) NOT NULL,
   password VARCHAR(255) NOT NULL,
   is_deleted BIT DEFAULT 0,
   Id_auteur INT,
   PRIMARY KEY(id),
   UNIQUE(Id_auteur),
   UNIQUE(login),
   FOREIGN KEY(Id_auteur) REFERENCES auteur(id)
);

CREATE TABLE image(
   id INT IDENTITY,
   filepath VARCHAR(255),
   titre VARCHAR(255),
   is_deleted BIT,
   PRIMARY KEY(id),
   UNIQUE(filepath)
);

CREATE TABLE article_tag(
   Id_article INT,
   Id_tag INT,
   PRIMARY KEY(Id_article, Id_tag),
   FOREIGN KEY(Id_article) REFERENCES article(id),
   FOREIGN KEY(Id_tag) REFERENCES tag(id)
);

CREATE TABLE article_image(
   Id_article INT,
   Id_image INT,
   PRIMARY KEY(Id_article, Id_image),
   FOREIGN KEY(Id_article) REFERENCES article(id),
   FOREIGN KEY(Id_image) REFERENCES image(id)
);
