﻿using BlogSampleApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace BlogSampleApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        //permet de rechercher le dbcontext
        protected readonly AppDbContext _context;
        //permet de récup ce qu'il y a dans appsettings.json (les settings du jwt)
        private readonly IConfiguration _configuration;

        //lesdeux attributs ont les passe au constructeurs
        public AuthController(AppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        //rejouter pour que tout le monde y ait accès !!!!!!!!!!!!!!!
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(AppUser appUser)
        {
            //on verifie que le login (ou email/pseudo si tu te log avec ca) passer dans le post(url) soit le meme que celui de la BDD
            AppUser user = _context.AppUsers.SingleOrDefault(user => user.Login == appUser.Login);

            //si aucune ligne dans la base de données
            if (user == null)
            {
                return BadRequest("Invalid Credentials");
            }

            //sinon je contruis mon token
            //TODO 2.Check encrypted password
            string storedEncryptedPassword = user.Password.Split('$')[1];
            string b64salt = user.Password.Split('$')[0];
            byte[] salt = Convert.FromBase64String(b64salt);
            string inputEncryptedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: appUser.Password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8
            ));

            if (storedEncryptedPassword != inputEncryptedPassword)
            {
                return BadRequest("Invalid Credentials");
            }
            //creation du token ici.......................start....................
            //pas besoin de connaitre par coeur

            //claims => Correspond au payload
            var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("Id", user.Id.ToString()),
                        new Claim("Login", user.Login)
                    };
            //creer la clé
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:SigningKey"]));
            //signe la clé
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            //je créé le token
            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.UtcNow.AddMinutes(10),
                signingCredentials: signIn);
            //je le renvoie
            return Ok(new JwtSecurityTokenHandler().WriteToken(token));
        }
        //.....................................END...............................................

        //TODO 1.Register with encrypted password
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register(AppUser appUser)
        {
            AppUser user = _context.AppUsers.SingleOrDefault(user => user.Login == appUser.Login);

            if (user != null)
            {
                return BadRequest("Login already used");
            }
            //rajoute des caratères au mot de passe( salé le mot de pass )
            byte[] salt = new byte[256 / 8]; // Generate a 256-bit salt using a secure PRNG
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }
            //trasnforme en base 64 (transforme le mot de passe en caractères speciaux)
            string b64salt = Convert.ToBase64String(salt);

            string encryptedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: appUser.Password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8
            ));
            //concataine le b64salt  avec le mot de pass crypté
            appUser.Password = b64salt + "$" + encryptedPassword;
            _context.AppUsers.Add(appUser);
            _context.SaveChanges();

            return Ok(b64salt + "$" + encryptedPassword);
        }

    }
}
